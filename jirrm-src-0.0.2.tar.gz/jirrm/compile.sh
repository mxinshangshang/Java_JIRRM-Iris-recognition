#!/bin/bash
cd src
#javac -d ../build/classes -cp ~/Desktop/swt-M20060629-1905-gtk-linux-x86/swt.jar:. org/cs02rm0/jirrm/SWTFrame.java
javac -d ../build/classes -cp /usr/lib/java/swt.jar:. org/cs02rm0/jirrm/SWTFrame.java
